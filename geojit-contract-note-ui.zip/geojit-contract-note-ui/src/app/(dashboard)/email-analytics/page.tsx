"use client";

import { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { format, subDays } from "date-fns";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  Cell,
} from "recharts";
import { cn, fmtDateTime } from "@/lib/utils";
import { downloadCsv } from "@/lib/export";
import type {
  EngagementSummary,
  EngagementTimeSeries,
  SegmentEngagement,
  HourHeatmapCell,
  CustomerEngagement,
} from "@/types";

// ─── Mock flag ────────────────────────────────────────────────────────────────
const USE_MOCK = true;

// ─── Segments ─────────────────────────────────────────────────────────────────
const SEGMENTS = [
  "EQUITY-COMBINEMARGIN",
  "ROS",
  "BILL",
  "COMMODITY",
  "DP-HOLDING",
  "DP-HOLDING-YEARLY",
  "DP-LEDGER-WEEKLY",
  "DP-TRADE-TXN",
  "STT",
  "PNL",
  "AGTS",
  "QS-LEDGER",
  "QS-RETENTION",
  "DMR",
];

// ─── Mock Data Generators ─────────────────────────────────────────────────────
function buildMockSummary(): EngagementSummary {
  return {
    totalSent: 124350,
    openRate: 24.7,
    clickRate: 3.8,
    unsubscribeRate: 0.12,
    openRateTrend: 2.3,
    clickRateTrend: -0.5,
    sparklineOpens: [22, 25, 23, 26, 24, 25, 24.7],
    sparklineClicks: [3.5, 3.9, 4.1, 3.7, 3.8, 3.6, 3.8],
  };
}

function buildMockTimeSeries(): EngagementTimeSeries[] {
  return Array.from({ length: 30 }, (_, i) => {
    const date = format(subDays(new Date(), 29 - i), "yyyy-MM-dd");
    return {
      date,
      openRate: parseFloat((20 + Math.random() * 10).toFixed(1)),
      clickRate: parseFloat((2 + Math.random() * 3).toFixed(1)),
      bounceRate: parseFloat((0.5 + Math.random() * 2.5).toFixed(2)),
    };
  });
}

function buildMockSegments(): SegmentEngagement[] {
  return SEGMENTS.map((seg) => ({
    segment: seg,
    openRate: parseFloat((15 + Math.random() * 20).toFixed(1)),
    clickRate: parseFloat((1.5 + Math.random() * 4.5).toFixed(1)),
    sent: Math.floor(5000 + Math.random() * 20000),
  }));
}

function buildMockHeatmap(): HourHeatmapCell[] {
  const cells: HourHeatmapCell[] = [];
  // day: 0=Mon … 6=Sun
  for (let day = 0; day < 7; day++) {
    for (let hour = 0; hour < 24; hour++) {
      const isWeekday = day <= 4;
      const isWorkHour = hour >= 9 && hour <= 17;
      let base = isWeekday && isWorkHour ? 8 + Math.random() * 7 : 1 + Math.random() * 4;
      cells.push({ day, hour, clickRate: parseFloat(base.toFixed(2)) });
    }
  }
  return cells;
}

function buildMockCustomers(): CustomerEngagement[] {
  const partyCodes = [
    "GEO00123", "GEO00456", "GEO00789", "GEO01012", "GEO01345",
    "GEO01678", "GEO01901", "GEO02234", "GEO02567", "GEO02890",
    "GEO03123", "GEO03456", "GEO03789", "GEO04012", "GEO04345",
    "GEO04678", "GEO04901", "GEO05234", "GEO05567", "GEO05890",
  ];
  const bounceStatuses: Array<"NEVER" | "SOFT" | "HARD"> = ["NEVER", "NEVER", "NEVER", "SOFT", "HARD"];
  return partyCodes.map((code, i) => {
    const totalSent = 1 + Math.floor(Math.random() * 8);
    const opened = Math.floor(Math.random() * (totalSent + 1));
    const clicked = Math.floor(Math.random() * (opened + 1));
    const hasOpened = opened > 0;
    const hasClicked = clicked > 0;
    const baseDate = new Date(2025, 3, i + 1);
    return {
      partyCode: code,
      email: `client${i + 1}@example.com`,
      totalSent,
      opened,
      clicked,
      openRate: totalSent > 0 ? parseFloat(((opened / totalSent) * 100).toFixed(1)) : 0,
      clickRate: totalSent > 0 ? parseFloat(((clicked / totalSent) * 100).toFixed(1)) : 0,
      lastOpenedAt: hasOpened ? baseDate.toISOString() : undefined,
      lastClickedAt: hasClicked ? new Date(baseDate.getTime() + 3600000).toISOString() : undefined,
      bounceStatus: bounceStatuses[i % bounceStatuses.length],
    };
  });
}

// ─── SparklineChart ───────────────────────────────────────────────────────────
function SparklineChart({ data, color }: { data: number[]; color: string }) {
  const d = data.map((v, i) => ({ v, i }));
  return (
    <ResponsiveContainer width={120} height={40}>
      <LineChart data={d} margin={{ top: 4, right: 4, left: 4, bottom: 4 }}>
        <Line type="monotone" dataKey="v" stroke={color} strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

// ─── Custom Tooltip for Trends Chart ─────────────────────────────────────────
function TrendTooltip({ active, payload, label }: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-slate-200 rounded shadow-lg p-3 text-[11px]">
      <p className="font-semibold text-slate-700 mb-1">{label}</p>
      {payload.map((p) => (
        <p key={p.name} style={{ color: p.color }}>
          {p.name}: {p.value}%
        </p>
      ))}
    </div>
  );
}

// ─── Custom Tooltip for Bar Chart ────────────────────────────────────────────
function BarTooltipContent({ active, payload }: {
  active?: boolean;
  payload?: Array<{ payload: SegmentEngagement }>;
}) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div className="bg-white border border-slate-200 rounded shadow-lg p-3 text-[11px]">
      <p className="font-semibold text-slate-700 mb-1">{d.segment}</p>
      <p>Open Rate: <span className="font-bold">{d.openRate}%</span></p>
      <p>Click Rate: <span className="font-bold">{d.clickRate}%</span></p>
      <p>Sent: <span className="font-bold">{d.sent.toLocaleString()}</span></p>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function EmailAnalyticsPage() {
  const today = new Date();
  const [dateFrom, setDateFrom] = useState(format(subDays(today, 30), "yyyy-MM-dd"));
  const [dateTo, setDateTo] = useState(format(today, "yyyy-MM-dd"));
  const [segment, setSegment] = useState("");
  // job filter is hardcoded for now
  const [_job] = useState("all");

  const [summary, setSummary] = useState<EngagementSummary | null>(null);
  const [timeSeries, setTimeSeries] = useState<EngagementTimeSeries[]>([]);
  const [segments, setSegmentsData] = useState<SegmentEngagement[]>([]);
  const [heatmap, setHeatmap] = useState<HourHeatmapCell[]>([]);
  const [customers, setCustomers] = useState<CustomerEngagement[]>([]);

  const [loading, setLoading] = useState(true);

  // Customer table state
  const [search, setSearch] = useState("");
  const [custPage, setCustPage] = useState(0);
  const PAGE_SIZE = 10;

  // Heatmap hover state
  const [hoveredCell, setHoveredCell] = useState<{ day: number; hour: number; clickRate: number } | null>(null);

  // ── Fetch / mock data ─────────────────────────────────────────────────
  useEffect(() => {
    setLoading(true);
    if (USE_MOCK) {
      setSummary(buildMockSummary());
      setTimeSeries(buildMockTimeSeries());
      setSegmentsData(buildMockSegments());
      setHeatmap(buildMockHeatmap());
      setCustomers(buildMockCustomers());
      setLoading(false);
    } else {
      const params = { from: dateFrom, to: dateTo, segment: segment || undefined };
      Promise.all([
        fetch(`/api/analytics/engagement/summary?${new URLSearchParams(params as Record<string, string>)}`).then((r) => r.json()),
        fetch(`/api/analytics/engagement/timeseries?${new URLSearchParams(params as Record<string, string>)}`).then((r) => r.json()),
        fetch(`/api/analytics/engagement/by-segment?${new URLSearchParams(params as Record<string, string>)}`).then((r) => r.json()),
        fetch(`/api/analytics/engagement/heatmap?${new URLSearchParams(params as Record<string, string>)}`).then((r) => r.json()),
        fetch(`/api/analytics/engagement/customers?${new URLSearchParams(params as Record<string, string>)}`).then((r) => r.json()),
      ])
        .then(([s, ts, seg, hm, cust]) => {
          setSummary(s.data);
          setTimeSeries(ts.data);
          setSegmentsData(seg.data);
          setHeatmap(hm.data);
          setCustomers(cust.data?.content ?? cust.data ?? []);
        })
        .finally(() => setLoading(false));
    }
  }, [dateFrom, dateTo, segment]);

  // ── Derived data ──────────────────────────────────────────────────────
  const sortedSegments = useMemo(
    () => [...segments].sort((a, b) => b.openRate - a.openRate),
    [segments]
  );

  const maxHeatmapRate = useMemo(
    () => Math.max(...heatmap.map((c) => c.clickRate), 1),
    [heatmap]
  );

  const filteredCustomers = useMemo(() => {
    const q = search.toLowerCase();
    if (!q) return customers;
    return customers.filter(
      (c) =>
        c.partyCode.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q)
    );
  }, [customers, search]);

  const totalCustPages = Math.ceil(filteredCustomers.length / PAGE_SIZE);
  const custSlice = filteredCustomers.slice(custPage * PAGE_SIZE, (custPage + 1) * PAGE_SIZE);

  // Reset page when search changes
  useEffect(() => {
    setCustPage(0);
  }, [search]);

  // ── CSV Export ────────────────────────────────────────────────────────
  function handleExportCsv() {
    const headers = [
      "Party Code", "Email", "Total Sent", "Opened", "Open Rate",
      "Clicked", "Click Rate", "Last Opened", "Last Clicked", "Bounce Status",
    ];
    const rows = filteredCustomers.map((c) => [
      c.partyCode,
      c.email,
      String(c.totalSent),
      String(c.opened),
      `${c.openRate}%`,
      String(c.clicked),
      `${c.clickRate}%`,
      c.lastOpenedAt ? fmtDateTime(c.lastOpenedAt) : "Never",
      c.lastClickedAt ? fmtDateTime(c.lastClickedAt) : "Never",
      c.bounceStatus,
    ]);
    downloadCsv("customer-engagement.csv", headers, rows);
  }

  // ── Day labels ────────────────────────────────────────────────────────
  const DAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <span className="material-symbols-outlined animate-spin text-[#497cff] text-4xl">progress_activity</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 pb-10">
      {/* ── Page Header ─────────────────────────────────────────────────── */}
      <div className="px-6 pt-6">
        <h2 className="headline text-xl font-bold text-slate-900">Email Analytics</h2>
        <p className="text-sm text-slate-500 mt-0.5">
          Open &amp; click engagement across all campaigns.
        </p>
      </div>

      {/* ── Filter Bar ──────────────────────────────────────────────────── */}
      <div className="sticky top-0 z-20 bg-white border-b border-slate-200 px-6 py-3 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">From</label>
          <input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="border border-slate-200 rounded px-2 py-1 text-[12px] text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#497cff]/30"
          />
        </div>
        <div className="flex items-center gap-2">
          <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">To</label>
          <input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="border border-slate-200 rounded px-2 py-1 text-[12px] text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#497cff]/30"
          />
        </div>
        <div className="flex items-center gap-2">
          <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Segment</label>
          <select
            value={segment}
            onChange={(e) => setSegment(e.target.value)}
            className="border border-slate-200 rounded px-2 py-1 text-[12px] text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#497cff]/30"
          >
            <option value="">All Segments</option>
            {SEGMENTS.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Job</label>
          <select
            disabled
            className="border border-slate-200 rounded px-2 py-1 text-[12px] text-slate-400 bg-slate-50 cursor-not-allowed"
          >
            <option>All Jobs</option>
          </select>
        </div>
      </div>

      <div className="px-6 flex flex-col gap-6">
        {/* ── Section 1: KPI Cards ───────────────────────────────────────── */}
        {summary && (
          <div className="grid grid-cols-4 gap-4">
            {/* Total Sent */}
            <div className="card p-5 flex flex-col gap-1">
              <p className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Total Sent</p>
              <p className="text-[28px] font-extrabold mono text-slate-900 leading-none">
                {summary.totalSent.toLocaleString()}
              </p>
              <span
                className={cn(
                  "text-[11px] font-semibold w-fit px-1.5 py-0.5 rounded",
                  summary.openRateTrend >= 0
                    ? "bg-green-50 text-green-700"
                    : "bg-red-50 text-red-600"
                )}
              >
                {summary.openRateTrend >= 0 ? "▲" : "▼"} {summary.openRateTrend >= 0 ? "+" : ""}{summary.openRateTrend}%
              </span>
              <div className="mt-1">
                <SparklineChart data={summary.sparklineOpens} color="#497cff" />
              </div>
            </div>

            {/* Open Rate */}
            <div className="card p-5 flex flex-col gap-1">
              <p className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Open Rate</p>
              <p className="text-[28px] font-extrabold mono text-slate-900 leading-none">
                {summary.openRate}%
              </p>
              <span
                className={cn(
                  "text-[11px] font-semibold w-fit px-1.5 py-0.5 rounded",
                  summary.openRateTrend >= 0
                    ? "bg-green-50 text-green-700"
                    : "bg-red-50 text-red-600"
                )}
              >
                {summary.openRateTrend >= 0 ? "▲" : "▼"} {summary.openRateTrend >= 0 ? "+" : ""}{summary.openRateTrend}%
              </span>
              <p className="text-[10px] text-slate-400">Industry avg: 22%</p>
              <div className="mt-1">
                <SparklineChart data={summary.sparklineOpens} color="#497cff" />
              </div>
            </div>

            {/* Click Rate */}
            <div className="card p-5 flex flex-col gap-1">
              <p className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Click Rate</p>
              <p className="text-[28px] font-extrabold mono text-slate-900 leading-none">
                {summary.clickRate}%
              </p>
              <span
                className={cn(
                  "text-[11px] font-semibold w-fit px-1.5 py-0.5 rounded",
                  summary.clickRateTrend >= 0
                    ? "bg-green-50 text-green-700"
                    : "bg-red-50 text-red-600"
                )}
              >
                {summary.clickRateTrend >= 0 ? "▲" : "▼"} {summary.clickRateTrend >= 0 ? "+" : ""}{summary.clickRateTrend}%
              </span>
              <p className="text-[10px] text-slate-400">Industry avg: 3.5%</p>
              <div className="mt-1">
                <SparklineChart data={summary.sparklineClicks} color="#22c55e" />
              </div>
            </div>

            {/* Unsubscribe Rate */}
            <div className="card p-5 flex flex-col gap-1">
              <p className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Unsubscribe Rate</p>
              <p
                className="text-[28px] font-extrabold mono leading-none"
                style={{ color: summary.unsubscribeRate > 0.5 ? "#ef4444" : "#22c55e" }}
              >
                {summary.unsubscribeRate}%
              </p>
              <p className="text-[10px] text-slate-400">Target: &lt;0.5%</p>
              <div className="mt-1">
                <SparklineChart
                  data={[0.1, 0.13, 0.11, 0.14, 0.12, 0.12, summary.unsubscribeRate]}
                  color={summary.unsubscribeRate > 0.5 ? "#ef4444" : "#22c55e"}
                />
              </div>
            </div>
          </div>
        )}

        {/* ── Section 2: Engagement Trends ──────────────────────────────── */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Engagement Trends</h3>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5">
                <span className="w-4 h-0.5 inline-block rounded" style={{ backgroundColor: "#497cff" }} />
                <span className="text-slate-600">Opens</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-4 h-0.5 inline-block rounded" style={{ backgroundColor: "#22c55e" }} />
                <span className="text-slate-600">Clicks</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-4 h-0.5 inline-block rounded" style={{ backgroundColor: "#ef4444" }} />
                <span className="text-slate-600">Bounces</span>
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={timeSeries} margin={{ top: 4, right: 8, left: 0, bottom: 4 }}>
              <XAxis
                dataKey="date"
                tickFormatter={(v, i) => (i % 5 === 0 ? format(new Date(v), "dd MMM") : "")}
                tick={{ fontSize: 10, fill: "#94a3b8" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tickFormatter={(v) => `${v}%`}
                tick={{ fontSize: 10, fill: "#94a3b8" }}
                axisLine={false}
                tickLine={false}
                width={36}
              />
              <Tooltip content={<TrendTooltip />} />
              <Line
                type="monotone"
                dataKey="openRate"
                stroke="#497cff"
                strokeWidth={2}
                dot={false}
                name="Opens"
              />
              <Line
                type="monotone"
                dataKey="clickRate"
                stroke="#22c55e"
                strokeWidth={2}
                dot={false}
                name="Clicks"
              />
              <Line
                type="monotone"
                dataKey="bounceRate"
                stroke="#ef4444"
                strokeWidth={2}
                dot={false}
                name="Bounces"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* ── Section 3: Bar + Heatmap ───────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-4">
          {/* Open Rate by Segment */}
          <div className="card p-5">
            <h3 className="font-semibold text-slate-800 mb-4">Open Rate by Segment</h3>
            <ResponsiveContainer width="100%" height={420}>
              <BarChart
                data={sortedSegments}
                layout="vertical"
                margin={{ top: 4, right: 16, left: 4, bottom: 4 }}
              >
                <XAxis
                  type="number"
                  tickFormatter={(v) => `${v}%`}
                  tick={{ fontSize: 10, fill: "#94a3b8" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  type="category"
                  dataKey="segment"
                  width={160}
                  tick={{ fontSize: 10, fill: "#64748b" }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={<BarTooltipContent />} />
                <Bar dataKey="openRate" radius={[0, 3, 3, 0]}>
                  {sortedSegments.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={
                        entry.openRate > 25
                          ? "#22c55e"
                          : entry.openRate >= 15
                          ? "#f59e0b"
                          : "#ef4444"
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Heatmap */}
          <div className="card p-5">
            <h3 className="font-semibold text-slate-800 mb-4">Best Time to Send — Click Heatmap</h3>
            <div className="overflow-x-auto">
              {/* Hour labels */}
              <div className="flex ml-[52px] mb-0.5">
                {Array.from({ length: 24 }, (_, h) => (
                  <div
                    key={h}
                    className="text-[8px] text-slate-400 text-center"
                    style={{ width: 28, flexShrink: 0 }}
                  >
                    {h % 3 === 0 ? h : ""}
                  </div>
                ))}
              </div>
              {/* Grid rows */}
              {DAY_LABELS.map((dayLabel, dayIdx) => (
                <div key={dayIdx} className="flex items-center mb-0.5">
                  <div className="text-[10px] text-slate-500 w-[52px] shrink-0 font-medium pr-1 text-right">
                    {dayLabel}
                  </div>
                  {Array.from({ length: 24 }, (_, hour) => {
                    const cell = heatmap.find((c) => c.day === dayIdx && c.hour === hour);
                    const rate = cell?.clickRate ?? 0;
                    const intensity = Math.min(rate / maxHeatmapRate, 1);
                    const isHovered = hoveredCell?.day === dayIdx && hoveredCell?.hour === hour;
                    return (
                      <div
                        key={hour}
                        style={{
                          width: 28,
                          height: 28,
                          margin: 1,
                          flexShrink: 0,
                          borderRadius: 3,
                          backgroundColor:
                            intensity < 0.05
                              ? undefined
                              : `rgba(0, 23, 75, ${intensity})`,
                          cursor: "pointer",
                          outline: isHovered ? "2px solid #497cff" : "none",
                          position: "relative",
                        }}
                        className={cn(intensity < 0.05 ? "bg-slate-100" : "")}
                        onMouseEnter={() => setHoveredCell({ day: dayIdx, hour, clickRate: rate })}
                        onMouseLeave={() => setHoveredCell(null)}
                        title={`${dayLabel} ${hour}:00 — ${rate}% click rate`}
                      />
                    );
                  })}
                </div>
              ))}
              {/* Hovered tooltip */}
              {hoveredCell && (
                <div className="mt-2 text-[11px] text-slate-600 bg-slate-50 border border-slate-200 rounded px-3 py-1.5 w-fit">
                  <span className="font-semibold">{DAY_LABELS[hoveredCell.day]}</span>{" "}
                  {hoveredCell.hour}:00 —{" "}
                  <span className="font-semibold text-[#00174b]">{hoveredCell.clickRate}%</span> click rate
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── Section 4: Customer Engagement Table ───────────────────────── */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Customer Engagement</h3>
            <div className="flex items-center gap-3">
              <input
                type="text"
                placeholder="Search party or email…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="border border-slate-200 rounded px-3 py-1.5 text-[12px] text-slate-700 w-[200px] focus:outline-none focus:ring-2 focus:ring-[#497cff]/30"
              />
              <button
                onClick={handleExportCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#003ea8] hover:bg-[#002f8a] text-white text-[12px] font-semibold rounded transition-colors"
              >
                <span className="material-symbols-outlined text-[14px]">download</span>
                Export CSV
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="t-hd">
                  <th className="text-left px-3 py-2">Party Code</th>
                  <th className="text-left px-3 py-2">Email</th>
                  <th className="text-center px-3 py-2">Total Sent</th>
                  <th className="text-center px-3 py-2">Opened</th>
                  <th className="text-center px-3 py-2">Clicked</th>
                  <th className="text-left px-3 py-2">Last Opened</th>
                  <th className="text-left px-3 py-2">Last Clicked</th>
                  <th className="text-center px-3 py-2">Bounce Status</th>
                </tr>
              </thead>
              <tbody>
                {custSlice.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-10 text-slate-400">
                      No customers found.
                    </td>
                  </tr>
                ) : (
                  custSlice.map((c) => (
                    <tr key={c.partyCode} className="t-row">
                      <td className="px-3 py-2">
                        <Link
                          href={`/clients/${c.partyCode}`}
                          className="mono font-medium text-[#003ea8] hover:underline"
                        >
                          {c.partyCode}
                        </Link>
                      </td>
                      <td className="px-3 py-2 text-[11px] text-slate-600">{c.email}</td>
                      <td className="px-3 py-2 text-center mono">{c.totalSent}</td>
                      <td className="px-3 py-2 text-center">
                        <p className="font-bold text-slate-800">{c.opened}</p>
                        <p className="text-[10px] text-slate-400">{c.openRate}%</p>
                      </td>
                      <td className="px-3 py-2 text-center">
                        <p className="font-bold text-slate-800">{c.clicked}</p>
                        <p className="text-[10px] text-slate-400">{c.clickRate}%</p>
                      </td>
                      <td className="px-3 py-2 text-slate-600">
                        {c.lastOpenedAt ? fmtDateTime(c.lastOpenedAt) : (
                          <span className="text-slate-400">Never</span>
                        )}
                      </td>
                      <td className="px-3 py-2 text-slate-600">
                        {c.lastClickedAt ? fmtDateTime(c.lastClickedAt) : (
                          <span className="text-slate-400">Never</span>
                        )}
                      </td>
                      <td className="px-3 py-2 text-center">
                        <span
                          className={cn(
                            "pill",
                            c.bounceStatus === "NEVER" && "pill-neu",
                            c.bounceStatus === "SOFT" && "pill-warn",
                            c.bounceStatus === "HARD" && "pill-err"
                          )}
                        >
                          {c.bounceStatus}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between mt-4 text-[12px] text-slate-500">
            <span>
              {filteredCustomers.length === 0
                ? "0 customers"
                : `${custPage * PAGE_SIZE + 1}–${Math.min((custPage + 1) * PAGE_SIZE, filteredCustomers.length)} of ${filteredCustomers.length} customers`}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCustPage((p) => Math.max(0, p - 1))}
                disabled={custPage === 0}
                className="px-3 py-1 border border-slate-200 rounded text-[11px] font-medium disabled:opacity-40 hover:bg-slate-50 transition-colors"
              >
                Prev
              </button>
              <span className="mono text-slate-600">
                {totalCustPages > 0 ? `${custPage + 1} / ${totalCustPages}` : "—"}
              </span>
              <button
                onClick={() => setCustPage((p) => Math.min(totalCustPages - 1, p + 1))}
                disabled={custPage >= totalCustPages - 1}
                className="px-3 py-1 border border-slate-200 rounded text-[11px] font-medium disabled:opacity-40 hover:bg-slate-50 transition-colors"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}