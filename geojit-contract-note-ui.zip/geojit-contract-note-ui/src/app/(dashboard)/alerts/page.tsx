"use client";

import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { alertsApi } from "@/lib/api";
import type { AlertRule, AlertChannel, AlertTriggerEvent, AlertNotification } from "@/types";
import { toast } from "sonner";
import { cn, fmtDateTime } from "@/lib/utils";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import * as SwitchPrimitive from "@radix-ui/react-switch";

// ─── Constants ────────────────────────────────────────────────────────────────

const USE_MOCK = true;

const TRIGGER_LABELS: Record<AlertTriggerEvent, string> = {
  PFX_EXPIRY_WARNING: "PFX Expiry Warning",
  PFX_EXPIRY_CRITICAL: "PFX Expiry Critical",
  JOB_FAILED: "Job Failed",
  HIGH_BOUNCE_RATE: "High Bounce Rate",
  PIPELINE_STUCK: "Pipeline Stuck",
  EMAIL_QUOTA_NEAR_LIMIT: "Email Quota Near Limit",
  SES_CONFIG_DEACTIVATED: "SES Config Deactivated",
};

function triggerConditionLabel(rule: AlertRule): string {
  const t = rule.thresholdValue;
  switch (rule.triggerEvent) {
    case "PFX_EXPIRY_WARNING":
      return `Certificate expires in ≤ ${t} days`;
    case "PFX_EXPIRY_CRITICAL":
      return `Certificate expires in ≤ ${t} days (critical)`;
    case "JOB_FAILED":
      return "Any job status = FAILED";
    case "HIGH_BOUNCE_RATE":
      return `Bounce rate > ${t}% on any job`;
    case "PIPELINE_STUCK":
      return `Job in PROCESSING > ${t} hours`;
    case "EMAIL_QUOTA_NEAR_LIMIT":
      return "Email quota near limit";
    case "SES_CONFIG_DEACTIVATED":
      return "Active SES config deactivated";
    default:
      return rule.triggerEvent;
  }
}

function hasThreshold(event: AlertTriggerEvent): boolean {
  return ["PFX_EXPIRY_WARNING", "PFX_EXPIRY_CRITICAL", "HIGH_BOUNCE_RATE", "PIPELINE_STUCK"].includes(event);
}

function thresholdLabel(event: AlertTriggerEvent): string {
  switch (event) {
    case "PFX_EXPIRY_WARNING":
    case "PFX_EXPIRY_CRITICAL":
      return "Days before expiry";
    case "HIGH_BOUNCE_RATE":
      return "Bounce rate threshold (%)";
    case "PIPELINE_STUCK":
      return "Hours before flagging as stuck";
    default:
      return "Threshold value";
  }
}

function relativeTime(ts: string): string {
  const diff = Date.now() - new Date(ts.endsWith("Z") || ts.includes("+") ? ts : ts + "Z").getTime();
  const mins = Math.floor(diff / 60000);
  const hrs = Math.floor(mins / 60);
  const days = Math.floor(hrs / 24);
  if (days > 0) return `${days}d ago`;
  if (hrs > 0) return `${hrs}h ago`;
  if (mins > 0) return `${mins}m ago`;
  return "just now";
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

const MOCK_RULES: AlertRule[] = [
  {
    id: "1",
    name: "PFX Certificate Expiry",
    triggerEvent: "PFX_EXPIRY_WARNING",
    thresholdValue: 30,
    channels: ["EMAIL", "WHATSAPP"],
    recipients: [
      { channel: "EMAIL", value: "admin@geojit.com" },
      { channel: "WHATSAPP", value: "+91-9876543210" },
    ],
    includeDeepLink: true,
    isActive: true,
    createdAt: "2026-04-01T10:00:00Z",
    updatedAt: "2026-04-01T10:00:00Z",
  },
  {
    id: "2",
    name: "PFX Certificate Expiry (Critical)",
    triggerEvent: "PFX_EXPIRY_CRITICAL",
    thresholdValue: 7,
    channels: ["EMAIL", "SMS", "WHATSAPP"],
    recipients: [
      { channel: "EMAIL", value: "admin@geojit.com" },
      { channel: "SMS", value: "+91-9876543210" },
      { channel: "WHATSAPP", value: "+91-9876543210" },
    ],
    includeDeepLink: true,
    isActive: true,
    createdAt: "2026-04-01T10:00:00Z",
    updatedAt: "2026-04-01T10:00:00Z",
  },
  {
    id: "3",
    name: "Job Failure Alert",
    triggerEvent: "JOB_FAILED",
    channels: ["EMAIL"],
    recipients: [{ channel: "EMAIL", value: "ops@geojit.com" }],
    includeDeepLink: true,
    isActive: true,
    createdAt: "2026-04-02T08:00:00Z",
    updatedAt: "2026-04-02T08:00:00Z",
  },
  {
    id: "4",
    name: "High Bounce Rate",
    triggerEvent: "HIGH_BOUNCE_RATE",
    thresholdValue: 5,
    channels: ["EMAIL", "SMS"],
    recipients: [
      { channel: "EMAIL", value: "ops@geojit.com" },
      { channel: "SMS", value: "+91-9876543210" },
    ],
    includeDeepLink: false,
    isActive: true,
    createdAt: "2026-04-03T09:00:00Z",
    updatedAt: "2026-04-03T09:00:00Z",
  },
  {
    id: "5",
    name: "Pipeline Stuck Alert",
    triggerEvent: "PIPELINE_STUCK",
    thresholdValue: 2,
    channels: ["EMAIL"],
    recipients: [{ channel: "EMAIL", value: "admin@geojit.com" }],
    includeDeepLink: true,
    isActive: false,
    createdAt: "2026-04-04T11:00:00Z",
    updatedAt: "2026-04-04T11:00:00Z",
  },
];

const MOCK_HISTORY: AlertNotification[] = [
  {
    id: "h1",
    ruleId: "1",
    ruleName: "PFX Certificate Expiry",
    triggeredBy: "Certificate: geojit-prod.pfx",
    channel: "EMAIL",
    recipient: "admin@geojit.com",
    status: "SENT",
    sentAt: "2026-04-27T06:30:00Z",
  },
  {
    id: "h2",
    ruleId: "1",
    ruleName: "PFX Certificate Expiry",
    triggeredBy: "Certificate: geojit-prod.pfx",
    channel: "WHATSAPP",
    recipient: "+91-9876543210",
    status: "SENT",
    sentAt: "2026-04-27T06:30:00Z",
  },
  {
    id: "h3",
    ruleId: "3",
    ruleName: "Job Failure Alert",
    triggeredBy: "Job: EQUITY_20260426.xlsx",
    channel: "EMAIL",
    recipient: "ops@geojit.com",
    status: "SENT",
    sentAt: "2026-04-26T14:15:00Z",
  },
  {
    id: "h4",
    ruleId: "4",
    ruleName: "High Bounce Rate",
    triggeredBy: "Job: DERIVATIVE_20260425.xlsx (bounce 7.2%)",
    channel: "EMAIL",
    recipient: "ops@geojit.com",
    status: "FAILED",
    sentAt: "2026-04-25T18:45:00Z",
  },
  {
    id: "h5",
    ruleId: "4",
    ruleName: "High Bounce Rate",
    triggeredBy: "Job: DERIVATIVE_20260425.xlsx (bounce 7.2%)",
    channel: "SMS",
    recipient: "+91-9876543210",
    status: "FAILED",
    sentAt: "2026-04-25T18:45:00Z",
  },
  {
    id: "h6",
    ruleId: "2",
    ruleName: "PFX Certificate Expiry (Critical)",
    triggeredBy: "Certificate: geojit-prod.pfx (5 days left)",
    channel: "EMAIL",
    recipient: "admin@geojit.com",
    status: "PENDING",
    sentAt: "2026-04-24T09:00:00Z",
  },
  {
    id: "h7",
    ruleId: "3",
    ruleName: "Job Failure Alert",
    triggeredBy: "Job: COMMODITY_20260423.xlsx",
    channel: "EMAIL",
    recipient: "ops@geojit.com",
    status: "SENT",
    sentAt: "2026-04-23T11:20:00Z",
  },
];

// ─── Switch Component ─────────────────────────────────────────────────────────

function Switch({
  checked,
  onCheckedChange,
  disabled,
}: {
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <SwitchPrimitive.Root
      checked={checked}
      onCheckedChange={onCheckedChange}
      disabled={disabled}
      className={cn(
        "relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#497cff] focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
        checked ? "bg-[#00174b]" : "bg-slate-200"
      )}
    >
      <SwitchPrimitive.Thumb
        className={cn(
          "pointer-events-none block h-4 w-4 rounded-full bg-white shadow-lg ring-0 transition-transform",
          checked ? "translate-x-4" : "translate-x-0"
        )}
      />
    </SwitchPrimitive.Root>
  );
}

// ─── Channel config ───────────────────────────────────────────────────────────

const CHANNELS: { key: AlertChannel; label: string; icon: string; pillClass: string }[] = [
  { key: "EMAIL", label: "Email", icon: "mail", pillClass: "bg-blue-100 text-blue-700 border-blue-200" },
  { key: "SMS", label: "SMS", icon: "sms", pillClass: "bg-green-100 text-green-700 border-green-200" },
  { key: "WHATSAPP", label: "WhatsApp", icon: "chat", pillClass: "bg-emerald-100 text-emerald-700 border-emerald-200" },
];

const CHANNEL_INPUT_LABEL: Record<AlertChannel, string> = {
  EMAIL: "Email addresses",
  SMS: "Phone numbers",
  WHATSAPP: "WhatsApp numbers",
};

// ─── Tag Input Component ──────────────────────────────────────────────────────

function TagInput({
  channel,
  tags,
  onAdd,
  onRemove,
}: {
  channel: AlertChannel;
  tags: string[];
  onAdd: (v: string) => void;
  onRemove: (v: string) => void;
}) {
  const [inputVal, setInputVal] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  function isValidEmail(v: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  }

  function tryAdd(raw: string) {
    const val = raw.trim();
    if (!val) return;
    if (channel === "EMAIL" && !isValidEmail(val)) {
      toast.error(`"${val}" is not a valid email address`);
      return;
    }
    if (!tags.includes(val)) onAdd(val);
    setInputVal("");
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      tryAdd(inputVal);
    } else if (e.key === "Backspace" && !inputVal && tags.length > 0) {
      onRemove(tags[tags.length - 1]);
    }
  }

  return (
    <div
      className="min-h-[40px] w-full flex flex-wrap gap-1.5 items-center border border-slate-200 rounded-lg px-2.5 py-1.5 cursor-text bg-white focus-within:ring-2 focus-within:ring-[#497cff]/30 focus-within:border-[#497cff]"
      onClick={() => inputRef.current?.focus()}
    >
      {tags.map(tag => (
        <span
          key={tag}
          className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[11px] font-medium"
        >
          {tag}
          <button
            type="button"
            onClick={e => { e.stopPropagation(); onRemove(tag); }}
            className="text-slate-400 hover:text-slate-700 leading-none"
          >
            ×
          </button>
        </span>
      ))}
      <input
        ref={inputRef}
        value={inputVal}
        onChange={e => setInputVal(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={() => tryAdd(inputVal)}
        placeholder={tags.length === 0 ? (channel === "EMAIL" ? "user@example.com" : "+91-9876543210") : ""}
        className="flex-1 min-w-[120px] outline-none text-[12px] bg-transparent placeholder-slate-400"
      />
    </div>
  );
}

// ─── Form state type ──────────────────────────────────────────────────────────

type RecipientMap = Partial<Record<AlertChannel, string[]>>;

type DrawerForm = {
  name: string;
  triggerEvent: AlertTriggerEvent;
  thresholdValue: string;
  channels: AlertChannel[];
  recipients: RecipientMap;
  includeDeepLink: boolean;
};

function defaultForm(): DrawerForm {
  return {
    name: "",
    triggerEvent: "PFX_EXPIRY_WARNING",
    thresholdValue: "",
    channels: ["EMAIL"],
    recipients: { EMAIL: [] },
    includeDeepLink: false,
  };
}

function ruleToForm(rule: AlertRule): DrawerForm {
  const recipients: RecipientMap = {};
  for (const ch of rule.channels) {
    recipients[ch] = rule.recipients.filter(r => r.channel === ch).map(r => r.value);
  }
  return {
    name: rule.name,
    triggerEvent: rule.triggerEvent,
    thresholdValue: rule.thresholdValue !== undefined ? String(rule.thresholdValue) : "",
    channels: [...rule.channels],
    recipients,
    includeDeepLink: rule.includeDeepLink,
  };
}

// ─── History filter state ─────────────────────────────────────────────────────

type HistChannelFilter = "ALL" | AlertChannel;
type HistStatusFilter = "ALL" | "SENT" | "FAILED" | "PENDING";

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function AlertsPage() {
  const qc = useQueryClient();

  // ── Rules state ──────────────────────────────────────────────────────────
  const [rules, setRules] = useState<AlertRule[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<AlertRule | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AlertRule | null>(null);
  const [form, setForm] = useState<DrawerForm>(defaultForm());

  // ── History state ─────────────────────────────────────────────────────────
  const [history, setHistory] = useState<AlertNotification[]>([]);
  const [histFrom, setHistFrom] = useState("");
  const [histTo, setHistTo] = useState("");
  const [histRuleFilter, setHistRuleFilter] = useState("ALL");
  const [histChannel, setHistChannel] = useState<HistChannelFilter>("ALL");
  const [histStatus, setHistStatus] = useState<HistStatusFilter>("ALL");
  const [histPage, setHistPage] = useState(0);
  const HIST_SIZE = 50;

  // ── Load rules ────────────────────────────────────────────────────────────
  const { isLoading: rulesLoading } = useQuery({
    queryKey: ["alert-rules"],
    queryFn: async () => {
      if (USE_MOCK) return MOCK_RULES;
      const res = await alertsApi.getRules();
      return (res.data?.data ?? []) as AlertRule[];
    },
    onSuccess: (data: AlertRule[]) => setRules(data),
  } as Parameters<typeof useQuery>[0]);

  // ── Load history ──────────────────────────────────────────────────────────
  const { isLoading: histLoading } = useQuery({
    queryKey: ["alert-history"],
    queryFn: async () => {
      if (USE_MOCK) return MOCK_HISTORY;
      const res = await alertsApi.getHistory({});
      return (res.data?.data?.content ?? res.data?.data ?? []) as AlertNotification[];
    },
    onSuccess: (data: AlertNotification[]) => setHistory(data),
  } as Parameters<typeof useQuery>[0]);

  // ── Toggle rule ───────────────────────────────────────────────────────────
  const { mutate: toggleRule } = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      if (!USE_MOCK) await alertsApi.toggleRule(id, isActive);
    },
    onSuccess: (_data, vars) => {
      setRules(prev => prev.map(r => r.id === vars.id ? { ...r, isActive: vars.isActive } : r));
      toast.success(vars.isActive ? "Alert rule enabled" : "Alert rule disabled");
    },
    onError: () => toast.error("Failed to update rule status"),
  });

  // ── Create/Update rule ────────────────────────────────────────────────────
  const { mutate: saveRule, isPending: saving } = useMutation({
    mutationFn: async (payload: Omit<AlertRule, "id" | "createdAt" | "updatedAt">) => {
      if (USE_MOCK) {
        if (editingRule) {
          return { ...editingRule, ...payload, updatedAt: new Date().toISOString() };
        }
        return {
          ...payload,
          id: String(Date.now()),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        } as AlertRule;
      }
      if (editingRule) {
        const res = await alertsApi.updateRule(editingRule.id, payload);
        return res.data?.data as AlertRule;
      }
      const res = await alertsApi.createRule(payload);
      return res.data?.data as AlertRule;
    },
    onSuccess: (saved: AlertRule) => {
      if (editingRule) {
        setRules(prev => prev.map(r => r.id === saved.id ? saved : r));
        toast.success("Alert rule updated");
      } else {
        setRules(prev => [...prev, saved]);
        toast.success("Alert rule created");
      }
      closeDrawer();
      qc.invalidateQueries({ queryKey: ["alert-rules"] });
    },
    onError: () => toast.error("Failed to save alert rule"),
  });

  // ── Delete rule ───────────────────────────────────────────────────────────
  const { mutate: deleteRule } = useMutation({
    mutationFn: async (id: string) => {
      if (!USE_MOCK) await alertsApi.deleteRule(id);
    },
    onSuccess: (_data, id) => {
      setRules(prev => prev.filter(r => r.id !== id));
      setDeleteTarget(null);
      toast.success("Alert rule deleted");
      qc.invalidateQueries({ queryKey: ["alert-rules"] });
    },
    onError: () => toast.error("Failed to delete rule"),
  });

  // ── Resend notification ───────────────────────────────────────────────────
  const { mutate: resendNotif } = useMutation({
    mutationFn: async (id: string) => {
      if (!USE_MOCK) await alertsApi.resendNotification(id);
    },
    onSuccess: () => toast.success("Notification resend triggered"),
    onError: () => toast.error("Failed to resend notification"),
  });

  // ── Drawer helpers ────────────────────────────────────────────────────────
  function openCreateDrawer() {
    setEditingRule(null);
    setForm(defaultForm());
    setDrawerOpen(true);
  }

  function openEditDrawer(rule: AlertRule) {
    setEditingRule(rule);
    setForm(ruleToForm(rule));
    setDrawerOpen(true);
  }

  function closeDrawer() {
    setDrawerOpen(false);
    setEditingRule(null);
    setForm(defaultForm());
  }

  function toggleChannel(ch: AlertChannel) {
    setForm(prev => {
      const active = prev.channels.includes(ch);
      const channels = active
        ? prev.channels.filter(c => c !== ch)
        : [...prev.channels, ch];
      const recipients = { ...prev.recipients };
      if (!active) {
        if (!recipients[ch]) recipients[ch] = [];
      } else {
        delete recipients[ch];
      }
      return { ...prev, channels, recipients };
    });
  }

  function addRecipient(ch: AlertChannel, val: string) {
    setForm(prev => ({
      ...prev,
      recipients: { ...prev.recipients, [ch]: [...(prev.recipients[ch] ?? []), val] },
    }));
  }

  function removeRecipient(ch: AlertChannel, val: string) {
    setForm(prev => ({
      ...prev,
      recipients: { ...prev.recipients, [ch]: (prev.recipients[ch] ?? []).filter(v => v !== val) },
    }));
  }

  function handleSave() {
    if (!form.name.trim()) { toast.error("Alert name is required"); return; }
    if (form.channels.length === 0) { toast.error("Select at least one channel"); return; }

    const allRecipients: AlertRule["recipients"] = [];
    for (const ch of form.channels) {
      const vals = form.recipients[ch] ?? [];
      if (vals.length === 0) { toast.error(`Add at least one recipient for ${ch}`); return; }
      vals.forEach(v => allRecipients.push({ channel: ch, value: v }));
    }

    const payload: Omit<AlertRule, "id" | "createdAt" | "updatedAt"> = {
      name: form.name.trim(),
      triggerEvent: form.triggerEvent,
      thresholdValue: hasThreshold(form.triggerEvent) && form.thresholdValue
        ? Number(form.thresholdValue)
        : undefined,
      channels: form.channels,
      recipients: allRecipients,
      includeDeepLink: form.includeDeepLink,
      isActive: editingRule ? editingRule.isActive : true,
    };

    saveRule(payload);
  }

  // ── History filters ────────────────────────────────────────────────────────
  const filteredHistory = history.filter(n => {
    if (histFrom && n.sentAt < histFrom) return false;
    if (histTo && n.sentAt > histTo + "T23:59:59Z") return false;
    if (histRuleFilter !== "ALL" && n.ruleName !== histRuleFilter) return false;
    if (histChannel !== "ALL" && n.channel !== histChannel) return false;
    if (histStatus !== "ALL" && n.status !== histStatus) return false;
    return true;
  });

  const histTotalPages = Math.max(1, Math.ceil(filteredHistory.length / HIST_SIZE));
  const histPageData = filteredHistory.slice(histPage * HIST_SIZE, (histPage + 1) * HIST_SIZE);

  useEffect(() => { setHistPage(0); }, [histFrom, histTo, histRuleFilter, histChannel, histStatus]);

  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <>
      {/* Drawer overlay */}
      {drawerOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-40"
          onClick={closeDrawer}
        />
      )}

      {/* Drawer panel */}
      <div
        className={cn(
          "fixed right-0 top-0 bottom-0 w-[480px] bg-white shadow-2xl z-50 overflow-y-auto transition-transform duration-300",
          drawerOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        <DrawerContent
          form={form}
          setForm={setForm}
          editingRule={editingRule}
          saving={saving}
          onSave={handleSave}
          onClose={closeDrawer}
          toggleChannel={toggleChannel}
          addRecipient={addRecipient}
          removeRecipient={removeRecipient}
        />
      </div>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete &ldquo;{deleteTarget?.name}&rdquo;?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the alert rule. Notifications already sent will remain in history. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && deleteRule(deleteTarget.id)}
              className="bg-rose-600 hover:bg-rose-700 focus:ring-rose-600"
            >
              Delete rule
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Main content */}
      <div className="p-6 space-y-5 max-w-[1600px] mx-auto w-full fade-up">
        {/* Page header */}
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 headline">Alerts</h2>
            <p className="text-slate-500 text-sm mt-1">
              Configure automated notifications for critical system events.
            </p>
          </div>
          <button
            onClick={openCreateDrawer}
            className="px-4 py-2 bg-[#00174b] text-white rounded-xl text-sm font-bold hover:bg-[#003ea8] flex items-center gap-1.5"
          >
            <span className="material-symbols-outlined text-base">add</span>
            New Alert Rule
          </button>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="rules">
          <TabsList className="mb-4">
            <TabsTrigger value="rules">Alert Rules</TabsTrigger>
            <TabsTrigger value="history">Notification History</TabsTrigger>
          </TabsList>

          {/* ── Alert Rules Tab ── */}
          <TabsContent value="rules">
            <div className="card overflow-hidden">
              {rulesLoading ? (
                <div className="flex justify-center py-16">
                  <span className="material-symbols-outlined animate-spin text-[#00174b] text-3xl">progress_activity</span>
                </div>
              ) : rules.length === 0 ? (
                <div className="flex flex-col items-center gap-3 py-20 text-center">
                  <span className="material-symbols-outlined text-5xl text-slate-300">notifications_off</span>
                  <p className="text-slate-500 font-medium">No alert rules configured yet</p>
                  <p className="text-slate-400 text-sm">Set up rules to receive automated notifications for critical events.</p>
                  <button
                    onClick={openCreateDrawer}
                    className="mt-2 px-4 py-2 bg-[#00174b] text-white rounded-xl text-sm font-bold hover:bg-[#003ea8]"
                  >
                    Create your first rule
                  </button>
                </div>
              ) : (
                <table className="w-full text-left">
                  <thead>
                    <tr className="t-hd">
                      <th className="px-5 py-3.5">Alert Name</th>
                      <th className="px-5 py-3.5">Trigger Condition</th>
                      <th className="px-5 py-3.5">Channels</th>
                      <th className="px-5 py-3.5">Recipients</th>
                      <th className="px-5 py-3.5">Status</th>
                      <th className="px-5 py-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rules.map(rule => (
                      <tr key={rule.id} className="t-row">
                        {/* Alert Name */}
                        <td className="px-5 py-4">
                          <span className="text-sm font-semibold text-slate-900">{rule.name}</span>
                        </td>

                        {/* Trigger Condition */}
                        <td className="px-5 py-4">
                          <span className="text-[12px] text-slate-600">{triggerConditionLabel(rule)}</span>
                        </td>

                        {/* Channels */}
                        <td className="px-5 py-4">
                          <div className="flex gap-1 flex-wrap">
                            {CHANNELS.map(ch => {
                              const active = rule.channels.includes(ch.key);
                              return (
                                <span
                                  key={ch.key}
                                  className={cn(
                                    "inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[10px] font-semibold border",
                                    active
                                      ? ch.pillClass
                                      : "bg-slate-50 text-slate-300 border-slate-200"
                                  )}
                                >
                                  <span className="material-symbols-outlined text-[12px]">{ch.icon}</span>
                                  {ch.label}
                                </span>
                              );
                            })}
                          </div>
                        </td>

                        {/* Recipients */}
                        <td className="px-5 py-4">
                          <span className="text-[11px] text-slate-500 mono">
                            {(() => {
                              const all = rule.recipients.map(r => r.value).join(", ");
                              return all.length > 40 ? all.slice(0, 40) + "…" : all;
                            })()}
                          </span>
                        </td>

                        {/* Status switch */}
                        <td className="px-5 py-4">
                          <Switch
                            checked={rule.isActive}
                            onCheckedChange={v => toggleRule({ id: rule.id, isActive: v })}
                          />
                        </td>

                        {/* Actions */}
                        <td className="px-5 py-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => openEditDrawer(rule)}
                              className="p-1.5 text-slate-400 hover:text-[#003ea8] hover:bg-slate-100 rounded-lg transition-colors"
                              title="Edit rule"
                            >
                              <span className="material-symbols-outlined text-[18px]">edit</span>
                            </button>
                            <button
                              onClick={() => setDeleteTarget(rule)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                              title="Delete rule"
                            >
                              <span className="material-symbols-outlined text-[18px]">delete</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </TabsContent>

          {/* ── Notification History Tab ── */}
          <TabsContent value="history">
            <div className="space-y-4">
              {/* Filter bar */}
              <div className="card p-4">
                <div className="flex flex-wrap items-end gap-3">
                  {/* Date range */}
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">From</label>
                    <input
                      type="date"
                      value={histFrom}
                      onChange={e => setHistFrom(e.target.value)}
                      className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[12px]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">To</label>
                    <input
                      type="date"
                      value={histTo}
                      onChange={e => setHistTo(e.target.value)}
                      className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[12px]"
                    />
                  </div>

                  {/* Alert type */}
                  <div className="flex-1 min-w-[180px]">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Alert Type</label>
                    <select
                      value={histRuleFilter}
                      onChange={e => setHistRuleFilter(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[12px]"
                    >
                      <option value="ALL">All Types</option>
                      {rules.map(r => (
                        <option key={r.id} value={r.name}>{r.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Channel filter pills */}
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Channel</label>
                    <div className="flex gap-1">
                      {(["ALL", "EMAIL", "SMS", "WHATSAPP"] as const).map(ch => (
                        <button
                          key={ch}
                          onClick={() => setHistChannel(ch)}
                          className={cn(
                            "px-3 py-1.5 rounded-lg text-[11px] font-bold border transition-colors",
                            histChannel === ch
                              ? "bg-[#00174b] text-white border-[#00174b]"
                              : "bg-white text-slate-600 border-slate-200 hover:border-slate-400"
                          )}
                        >
                          {ch === "ALL" ? "All" : ch.charAt(0) + ch.slice(1).toLowerCase()}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Status filter pills */}
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Status</label>
                    <div className="flex gap-1">
                      {(["ALL", "SENT", "FAILED", "PENDING"] as const).map(s => (
                        <button
                          key={s}
                          onClick={() => setHistStatus(s)}
                          className={cn(
                            "px-3 py-1.5 rounded-lg text-[11px] font-bold border transition-colors",
                            histStatus === s
                              ? "bg-[#00174b] text-white border-[#00174b]"
                              : "bg-white text-slate-600 border-slate-200 hover:border-slate-400"
                          )}
                        >
                          {s === "ALL" ? "All" : s.charAt(0) + s.slice(1).toLowerCase()}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* History table */}
              <div className="card overflow-hidden">
                {histLoading ? (
                  <div className="flex justify-center py-16">
                    <span className="material-symbols-outlined animate-spin text-[#00174b] text-3xl">progress_activity</span>
                  </div>
                ) : histPageData.length === 0 ? (
                  <div className="flex flex-col items-center gap-3 py-16 text-center">
                    <span className="material-symbols-outlined text-4xl text-slate-300">inbox</span>
                    <p className="text-slate-500 text-sm">No notification history found</p>
                  </div>
                ) : (
                  <table className="w-full text-left">
                    <thead>
                      <tr className="t-hd">
                        <th className="px-5 py-3.5">Timestamp</th>
                        <th className="px-5 py-3.5">Alert Rule</th>
                        <th className="px-5 py-3.5">Triggered By</th>
                        <th className="px-5 py-3.5">Channel</th>
                        <th className="px-5 py-3.5">Recipient</th>
                        <th className="px-5 py-3.5">Status</th>
                        <th className="px-5 py-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {histPageData.map(n => {
                        const chInfo = CHANNELS.find(c => c.key === n.channel);
                        return (
                          <tr key={n.id} className="t-row">
                            {/* Timestamp */}
                            <td className="px-5 py-4">
                              <div className="text-[12px] font-medium text-slate-900">{fmtDateTime(n.sentAt)}</div>
                              <div className="text-[10px] text-slate-400 mt-0.5">{relativeTime(n.sentAt)}</div>
                            </td>

                            {/* Alert Rule */}
                            <td className="px-5 py-4">
                              <span className="text-[12px] font-medium text-slate-800">{n.ruleName}</span>
                            </td>

                            {/* Triggered By */}
                            <td className="px-5 py-4">
                              <span className="text-[11px] text-slate-500 max-w-[180px] block truncate" title={n.triggeredBy}>
                                {n.triggeredBy}
                              </span>
                            </td>

                            {/* Channel */}
                            <td className="px-5 py-4">
                              {chInfo && (
                                <span className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border", chInfo.pillClass)}>
                                  <span className="material-symbols-outlined text-[12px]">{chInfo.icon}</span>
                                  {chInfo.label}
                                </span>
                              )}
                            </td>

                            {/* Recipient */}
                            <td className="px-5 py-4">
                              <span className="text-[11px] text-slate-600 mono">{n.recipient}</span>
                            </td>

                            {/* Status */}
                            <td className="px-5 py-4">
                              <span className={cn(
                                "pill",
                                n.status === "SENT" ? "pill-ok" :
                                n.status === "FAILED" ? "pill-err" :
                                "pill-warn"
                              )}>
                                {n.status.charAt(0) + n.status.slice(1).toLowerCase()}
                              </span>
                            </td>

                            {/* Resend */}
                            <td className="px-5 py-4 text-right">
                              <button
                                onClick={() => resendNotif(n.id)}
                                className="p-1.5 text-slate-400 hover:text-[#003ea8] hover:bg-slate-100 rounded-lg transition-colors"
                                title="Resend notification"
                              >
                                <span className="material-symbols-outlined text-[18px]">replay</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Pagination */}
              {histTotalPages > 1 && (
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[11px] text-slate-400">
                    Page {histPage + 1} of {histTotalPages} &nbsp;·&nbsp; {filteredHistory.length} result{filteredHistory.length !== 1 ? "s" : ""}
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setHistPage(p => p - 1)}
                      disabled={histPage === 0}
                      className="px-3 py-1.5 border border-slate-200 rounded-lg text-[12px] font-medium hover:bg-slate-50 disabled:opacity-40"
                    >
                      Prev
                    </button>
                    <button
                      onClick={() => setHistPage(p => p + 1)}
                      disabled={histPage >= histTotalPages - 1}
                      className="px-3 py-1.5 border border-slate-200 rounded-lg text-[12px] font-medium hover:bg-slate-50 disabled:opacity-40"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}

// ─── Drawer Content ───────────────────────────────────────────────────────────

function DrawerContent({
  form,
  setForm,
  editingRule,
  saving,
  onSave,
  onClose,
  toggleChannel,
  addRecipient,
  removeRecipient,
}: {
  form: DrawerForm;
  setForm: React.Dispatch<React.SetStateAction<DrawerForm>>;
  editingRule: AlertRule | null;
  saving: boolean;
  onSave: () => void;
  onClose: () => void;
  toggleChannel: (ch: AlertChannel) => void;
  addRecipient: (ch: AlertChannel, v: string) => void;
  removeRecipient: (ch: AlertChannel, v: string) => void;
}) {
  return (
    <div className="flex flex-col h-full">
      {/* Drawer header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
        <h3 className="text-base font-bold text-slate-900 headline">
          {editingRule ? "Edit Alert Rule" : "New Alert Rule"}
        </h3>
        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <span className="material-symbols-outlined text-xl">close</span>
        </button>
      </div>

      {/* Drawer body */}
      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
        {/* 1. Alert Name */}
        <div>
          <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block mb-1.5 field-label">
            Alert Name
          </label>
          <input
            value={form.name}
            onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            placeholder="e.g. PFX Certificate Expiry"
            className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#497cff]/30 focus:border-[#497cff]"
          />
        </div>

        {/* 2. Trigger Event */}
        <div>
          <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block mb-1.5 field-label">
            Trigger Event
          </label>
          <select
            value={form.triggerEvent}
            onChange={e => setForm(f => ({ ...f, triggerEvent: e.target.value as AlertTriggerEvent, thresholdValue: "" }))}
            className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#497cff]/30 focus:border-[#497cff]"
          >
            {(Object.keys(TRIGGER_LABELS) as AlertTriggerEvent[]).map(ev => (
              <option key={ev} value={ev}>{TRIGGER_LABELS[ev]}</option>
            ))}
          </select>
        </div>

        {/* 3. Threshold (conditional) */}
        {hasThreshold(form.triggerEvent) && (
          <div>
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block mb-1.5 field-label">
              {thresholdLabel(form.triggerEvent)}
            </label>
            <input
              type="number"
              min={1}
              value={form.thresholdValue}
              onChange={e => setForm(f => ({ ...f, thresholdValue: e.target.value }))}
              placeholder="e.g. 30"
              className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#497cff]/30 focus:border-[#497cff]"
            />
          </div>
        )}

        {/* 4. Channels */}
        <div>
          <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block mb-1.5 field-label">
            Channels
          </label>
          <div className="grid grid-cols-3 gap-2">
            {CHANNELS.map(ch => {
              const active = form.channels.includes(ch.key);
              return (
                <button
                  key={ch.key}
                  type="button"
                  onClick={() => toggleChannel(ch.key)}
                  className={cn(
                    "flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all",
                    active
                      ? "border-[#497cff] bg-blue-50"
                      : "border-slate-200 bg-white hover:border-slate-300"
                  )}
                >
                  <span className={cn(
                    "material-symbols-outlined text-2xl",
                    active ? "text-[#497cff]" : "text-slate-400"
                  )}>
                    {ch.icon}
                  </span>
                  <span className={cn("text-[11px] font-semibold", active ? "text-[#497cff]" : "text-slate-500")}>
                    {ch.label}
                  </span>
                  <Switch
                    checked={active}
                    onCheckedChange={() => toggleChannel(ch.key)}
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* 5. Recipients per channel */}
        {form.channels.length > 0 && (
          <div className="space-y-3">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block field-label">
              Recipients
            </label>
            {form.channels.map(ch => (
              <div key={ch}>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  {CHANNEL_INPUT_LABEL[ch]}
                </label>
                <TagInput
                  channel={ch}
                  tags={form.recipients[ch] ?? []}
                  onAdd={v => addRecipient(ch, v)}
                  onRemove={v => removeRecipient(ch, v)}
                />
                <p className="text-[10px] text-slate-400 mt-1">Press Enter or comma to add.</p>
              </div>
            ))}
          </div>
        )}

        {/* 6. Include Deep Link */}
        <div>
          <div className="flex items-center justify-between">
            <div>
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block field-label">
                Include Deep Link
              </label>
              <p className="text-[11px] text-slate-400 mt-0.5">Attach a direct link to the relevant page in notifications.</p>
            </div>
            <Switch
              checked={form.includeDeepLink}
              onCheckedChange={v => setForm(f => ({ ...f, includeDeepLink: v }))}
            />
          </div>
          {form.includeDeepLink && (
            <div className="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-2">
              <span className="material-symbols-outlined text-slate-400 text-base flex-shrink-0 mt-0.5">info</span>
              <p className="text-[11px] text-slate-600">
                Notifications will include a direct link to the relevant job or certificate page.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Drawer footer */}
      <div className="px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-3">
        <button
          onClick={onClose}
          className="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg text-sm font-semibold hover:bg-slate-50 transition-colors"
        >
          Cancel
        </button>
        <button
          onClick={onSave}
          disabled={saving}
          className="px-5 py-2 bg-[#00174b] text-white rounded-lg text-sm font-bold hover:bg-[#003ea8] disabled:opacity-50 flex items-center gap-1.5 transition-colors"
        >
          {saving && (
            <span className="material-symbols-outlined text-base animate-spin">progress_activity</span>
          )}
          Save Rule
        </button>
      </div>
    </div>
  );
}